#!/usr/bin/python2

import cgi
import commands

commands.getstatusoutput('sshpass -p redhat ssh -X satish@192.168.43.18 vlc')

raw_input()
