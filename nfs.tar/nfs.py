#!/usr/bin/python2

import commands

commands.getstatusoutput('mkdir /media/{}'.format(name))
commands.getstatusoutput('mount 192.168.43.18:/media/{} /media/{}'.format(name,name))

raw_input()
