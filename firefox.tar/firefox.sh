#!/usr/bin/bash

ssh -X admin@www.welkins.com firefox
sleep 3
