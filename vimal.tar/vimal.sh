#!/usr/bin/bash

yum install nfs-utils -y
mkdir /media/vimal
mount www.welkins.com:/media/vimal /media/vimal
